package magicGame.repositories.interfaces;

import magicGame.models.magics.Magic;

import java.util.Collection;
import java.util.List;

public class MagicRepositoryImpl implements MagicRepository<Magic> {
    private List<Magic> data;

    @Override
    public Collection<Magic> getData() {
        return null;
    }

    @Override
    public void addMagic(Magic model) {

    }

    @Override
    public boolean removeMagic(Magic model) {
        return false;
    }

    @Override
    public Magic findByName(String name) {
        return null;
    }
}
