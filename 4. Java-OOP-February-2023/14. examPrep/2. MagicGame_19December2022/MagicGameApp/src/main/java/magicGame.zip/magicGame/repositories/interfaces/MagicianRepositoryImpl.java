package magicGame.repositories.interfaces;

import magicGame.models.magicians.Magician;

import java.util.Collection;
import java.util.List;

public class MagicianRepositoryImpl implements MagicianRepository<Magician> {
    private List<Magician> data;


    @Override
    public Collection<Magician> getData() {
        return null;
    }

    @Override
    public void addMagician(Magician model) {

    }

    @Override
    public boolean removeMagician(Magician model) {
        return false;
    }

    @Override
    public Magician findByUsername(String name) {
        return null;
    }
}
